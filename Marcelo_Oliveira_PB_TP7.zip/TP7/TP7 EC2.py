import psutil
import time

io_status = psutil.net_io_counters(pernic=True)
nomes = []
for i in io_status:
  nomes.append(str(i))
for j in nomes:
  print(j)
  print("\t"+str(io_status[j]))
print('------------------------------------------------------------------------')
for i in range(2):
  time.sleep(1)
  io_status = psutil.net_io_counters(pernic=True)
  for j in nomes:
    print(j)
    print("\t"+str(io_status[j]))
  print('------------------------------------------------------------------------')