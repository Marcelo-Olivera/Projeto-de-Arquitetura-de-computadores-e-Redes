import sched, time, os, psutil, subprocess

scheduler = sched.scheduler(time.time, time.sleep)

def Long_event_1(name):
      print ('INICIO DO EVENTO:', time.ctime(), time.process_time(), name)
      lista = os.listdir()
      dic = {} # cria dicionário
      for i in lista: # Varia na lista dos arquivos e diretórios
          if os.path.isfile(i): # checa se é um arquivo
             # Cria uma lista para cada arquivo. Esta lista contém o
             # tamanho, data de criação e data de modificação.
             dic[i] = []
             dic[i].append(os.stat(i).st_size) # Tamanho
             dic[i].append(os.stat(i).st_atime) # Tempo de criação
             dic[i].append(os.stat(i).st_mtime) # Tempo de modificação

      titulo = '{:11}'.format("Tamanho") # 10 caracteres + 1 de espaço
     # Concatenar com 25 caracteres + 2 de espaços
      titulo = titulo + '{:27}'.format("Data de Modificação")
     # Concatenar com 25 caracteres + 2 de espaços
      titulo = titulo + '{:27}'.format("Data de Criação")
      titulo = titulo + "Nome"
      print(titulo)
      for i in dic:
          kb = dic[i][0]/1024
          tamanho = '{:10}'.format(str('{:.2f}'.format(kb)+' KB'))
          print(tamanho, time.ctime(dic[i][2]), " ", time.ctime(dic[i][1])," ", i)
      time.sleep(2)
      print ('FIM DO EVENTO:', time.ctime(), time.process_time())
      print()
      
def Long_event_2(name):
    print ('INICIO DO EVENTO:', time.ctime(), time.process_time(), name)
    def mostra_info(pid):
        try:
            p = psutil.Process(pid)
            texto = '{:6}'.format(pid)
            texto = texto + '{:11}'.format(p.num_threads())
            texto = texto + " " + time.ctime(p.create_time()) + " "
            texto = texto + '{:8.2f}'.format(p.cpu_times().user)
            texto = texto + '{:8.2f}'.format(p.cpu_times().system)
            texto = texto + '{:10.2f}'.format(p.memory_percent()) + " %"
            rss = p.memory_info().rss/1024/1024
            texto = texto + '{:10.2f}'.format(rss) + " MB"
            vms = p.memory_info().vms/1024/1024
            texto = texto + '{:10.2f}'.format(vms) + " MB"
            texto = texto + " " + p.exe()
            print(texto)
        except:
            pass
    titulo = '{:^7}'.format("PID")
    titulo = titulo + '{:^11}'.format("# THREADS")
    titulo = titulo + '{:^26}'.format("CRIAÇÃO")
    titulo = titulo + '{:^9}'.format("T. USU.")
    titulo = titulo + '{:^9}'.format("T. SIS.")
    titulo = titulo + '{:^12}'.format("MEM. (%)")
    titulo = titulo + '{:^12}'.format("RSS")
    titulo = titulo + '{:^12}'.format("VMS")
    titulo = titulo + " EXECUTÁVEL"
    print(titulo)
    lista = psutil.pids()
    for i in lista:
        mostra_info(i)
    print('FIM DO EVENTO:', time.ctime(), time.process_time())
    print()

def Long_event_3(name):
    print ('EVENTO:', time.ctime(), time.process_time(), name)
    pid = subprocess.Popen('notepad.exe').pid

    p = psutil.Process(pid)
    print('Nome: ', p.name())
    print('Executável: ', p.exe())
    print('Tempo de criação: ', time.ctime(p.create_time()))
    print('Tempo de usuário: ', p.cpu_times().user, 's')
    print('Tempo de sistema: ', p.cpu_times().system, 's')
    print('Percentual de uso de CPU:: ', p.cpu_percent(interval = 1.0), '%')
    perc_mem = '{:.2f}'.format(p.memory_percent())
    print('Percentual de uso de memória: ', perc_mem, '%')
    mem = '{:.2f}'.format(p.memory_info().rss/1024/1024)
    print('Uso de memória: ', mem, 'MB')
    print('Número de threads: ', p.num_threads())
    print ('FIM DO EVENTO:', time.ctime(), time.process_time())
    print()
    
print('INICIO:', time.ctime())
scheduler.enter(2, 3, Long_event_1, ('LISTA DE INFORMAÇÕES DE ARQUIVOS E DIRETÓRIOS',))
scheduler.enter(8, 2, Long_event_2, ('LISTA DE INFORAÇÕES DE PROCESSOS',))
scheduler.enter(8, 1, Long_event_3, ('LISTA DE INFORAÇÕES DE UM PROCESSO',))
print('CHAMADAS ESCALONADAS DA FUNÇÃO:', time.ctime(), time.process_time())

scheduler.run()